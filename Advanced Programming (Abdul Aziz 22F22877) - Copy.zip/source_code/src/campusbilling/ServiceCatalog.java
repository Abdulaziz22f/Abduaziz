package campusbilling;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// Task 4 menu. Keeps the services in an ArrayList and walks it with an Iterator.
public class ServiceCatalog {

    public static void main(String[] args) throws Exception {

        ArrayList<ServiceRecord> list = new ArrayList<>();
        list.add(new ServiceRecord("FD100", "Food Delivery",        2.50));
        list.add(new ServiceRecord("TR200", "Transport Booking",    4.00));
        list.add(new ServiceRecord("PR300", "Printing Service",     1.50));
        list.add(new ServiceRecord("EV400", "Event Ticket Booking", 6.00));
        list.add(new ServiceRecord("ST500", "Study Room Booking",   3.50));

        System.out.println("+-------------------------------------------------+");
        System.out.printf ("| %-47s |%n", "CampusConnect Oman  -  Service Catalog");
        System.out.printf ("| %-47s |%n", "Abdul Aziz Harith Salim Al Shibli (22F22877)");
        System.out.printf ("| %-47s |%n", "Module: COMP 20014.1  Advanced Programming");
        System.out.println("+-------------------------------------------------+");

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean keepGoing = true;

        while (keepGoing) {
            System.out.println();
            System.out.println("----- Service Catalog Menu -----");
            System.out.println("1. Add a service");
            System.out.println("2. Display all services");
            System.out.println("3. Remove a service by code");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1-4): ");
            String choice = reader.readLine().trim();

            if (choice.equals("1")) {
                System.out.print("New service code : ");
                String code = reader.readLine().trim().toUpperCase();
                System.out.print("Description      : ");
                String desc = reader.readLine().trim();
                System.out.print("Base fee (OMR)   : ");
                double fee = Double.parseDouble(reader.readLine().trim());
                list.add(new ServiceRecord(code, desc, fee));
                System.out.println("Added " + code + " (" + desc + ")");

            } else if (choice.equals("2")) {
                System.out.println("\nThere are " + list.size() + " services:");
                Iterator<ServiceRecord> walk = list.iterator();
                while (walk.hasNext()) {
                    ServiceRecord s = walk.next();
                    System.out.printf("  %-6s %-22s OMR %.2f%n",
                            s.getCode(), s.getDescription(), s.getBaseFee());
                }

            } else if (choice.equals("3")) {
                System.out.print("Code to remove   : ");
                String target = reader.readLine().trim().toUpperCase();
                boolean done = false;
                Iterator<ServiceRecord> walk = list.iterator();
                while (walk.hasNext()) {
                    if (walk.next().getCode().equalsIgnoreCase(target)) {
                        walk.remove();
                        done = true;
                        break;
                    }
                }
                System.out.println(done ? "Removed " + target : "No service with code " + target);

            } else if (choice.equals("4")) {
                keepGoing = false;
                System.out.println("Closing the catalog. Goodbye.");

            } else {
                System.out.println("Please enter a number from 1 to 4.");
            }
        }
    }
}
