package campusbilling;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// holds one service: its code, description and base fee
public class ServiceRecord {

    private String code;
    private String description;
    private double baseFee;

    public ServiceRecord(String code, String description, double baseFee) {
        this.code = code;
        this.description = description;
        this.baseFee = baseFee;
    }

    public String getCode()        { return code; }
    public String getDescription() { return description; }
    public double getBaseFee()     { return baseFee; }
}
