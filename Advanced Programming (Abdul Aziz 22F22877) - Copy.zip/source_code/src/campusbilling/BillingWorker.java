package campusbilling;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// deals with a single student on a thread of its own. Pulls in the request, fetches
// the rows, computes the bill and posts a response back.
public class BillingWorker extends Thread {

    private Socket socket;

    public BillingWorker(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input  = new ObjectInputStream(socket.getInputStream())
        ) {
            BillRequest request = (BillRequest) input.readObject();
            System.out.println("Serving student " + request.getStudentId()
                    + " | service " + request.getServiceCode()
                    + " | priority " + request.getPriority());

            DatabaseManager db = new DatabaseManager();
            StudentRecord student = db.lookupStudent(request.getStudentId());
            ServiceRecord service = db.lookupService(request.getServiceCode());

            BillResponse response;
            if (student == null) {
                response = new BillResponse("Student id " + request.getStudentId() + " was not found.");
            } else if (service == null) {
                response = new BillResponse("Service code " + request.getServiceCode() + " was not found.");
            } else {
                response = new BillingCalculator().computeBill(student, service, request.getPriority());
            }

            output.writeObject(response);
            output.flush();

        } catch (Exception e) {
            System.out.println("Worker error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (Exception ignore) { }
        }
    }
}
