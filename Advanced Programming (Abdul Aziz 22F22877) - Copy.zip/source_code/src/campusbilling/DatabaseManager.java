package campusbilling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// JDBC class. Loads the driver, then reads a student or a service with a
// PreparedStatement (the ? keeps it safe). Returns null if nothing matched.
public class DatabaseManager {

    private static final String URL  = "jdbc:mysql://localhost:3306/campusconnect";
    private static final String USER = "root";
    private static final String PASS = "your_password_here";   // put your own MySQL password here

    public DatabaseManager() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver not found: " + ex.getMessage());
        }
    }

    public StudentRecord lookupStudent(int id) {
        Connection link = null;
        StudentRecord found = null;
        try {
            link = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = link.prepareStatement(
                    "SELECT id, name, age, scholarship_type FROM student WHERE id = ?");
            ps.setInt(1, id);
            ResultSet rows = ps.executeQuery();
            if (rows.next()) {
                found = new StudentRecord(rows.getInt("id"), rows.getString("name"),
                        rows.getInt("age"), rows.getString("scholarship_type"));
            }
        } catch (Exception ex) {
            System.out.println("Could not read student: " + ex.getMessage());
        } finally {
            close(link);
        }
        return found;
    }

    public ServiceRecord lookupService(String code) {
        Connection link = null;
        ServiceRecord found = null;
        try {
            link = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = link.prepareStatement(
                    "SELECT service_code, description, base_fee FROM service WHERE service_code = ?");
            ps.setString(1, code);
            ResultSet rows = ps.executeQuery();
            if (rows.next()) {
                found = new ServiceRecord(rows.getString("service_code"),
                        rows.getString("description"), rows.getDouble("base_fee"));
            }
        } catch (Exception ex) {
            System.out.println("Could not read service: " + ex.getMessage());
        } finally {
            close(link);
        }
        return found;
    }

    private void close(Connection link) {
        if (link != null) {
            try { link.close(); } catch (Exception ignore) { }
        }
    }
}
