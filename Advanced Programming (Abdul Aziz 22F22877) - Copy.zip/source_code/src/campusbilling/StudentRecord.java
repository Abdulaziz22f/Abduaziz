package campusbilling;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// a plain holder for one row read out of the student table.
public class StudentRecord {

    private int id;
    private String fullName;
    private int age;
    private String scholarship;

    public StudentRecord(int id, String fullName, int age, String scholarship) {
        this.id = id;
        this.fullName = fullName;
        this.age = age;
        this.scholarship = scholarship;
    }

    public int getId()            { return id; }
    public String getFullName()   { return fullName; }
    public int getAge()           { return age; }
    public String getScholarship(){ return scholarship; }
}
