package campusbilling;

import java.io.Serializable;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// what the client packs up (id, service code, priority) and ships to the server.
// it implements Serializable, so the whole object can be written down the stream.
public class BillRequest implements Serializable {

    private int studentId;
    private String serviceCode;
    private String priority;

    public BillRequest(int studentId, String serviceCode, String priority) {
        this.studentId = studentId;
        this.serviceCode = serviceCode;
        this.priority = priority;
    }

    public int getStudentId()      { return studentId; }
    public String getServiceCode() { return serviceCode; }
    public String getPriority()    { return priority; }
}
