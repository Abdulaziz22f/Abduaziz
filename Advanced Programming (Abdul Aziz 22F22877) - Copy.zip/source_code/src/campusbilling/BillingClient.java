package campusbilling;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// the student side (extends Thread). It gathers the three inputs through a BufferedReader,
// packs them into a BillRequest, and shows whatever BillResponse comes back.
public class BillingClient extends Thread {

    private static final String HOST = "localhost";
    private static final int PORT = 5050;

    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("+-------------------------------------------------+");
            System.out.printf ("| %-47s |%n", "CampusConnect Oman  -  Billing Client");
            System.out.printf ("| %-47s |%n", "Abdul Aziz Harith Salim Al Shibli (22F22877)");
            System.out.printf ("| %-47s |%n", "Module: COMP 20014.1  Advanced Programming");
            System.out.println("+-------------------------------------------------+");
            System.out.println();

            System.out.print("Student id        : ");
            String idText = reader.readLine().trim();
            if (!idText.matches("\\d+")) {
                System.out.println("The student id must contain digits only.");
                return;
            }
            int studentId = Integer.parseInt(idText);

            System.out.print("Service code      : ");
            String serviceCode = reader.readLine().trim().toUpperCase();
            if (serviceCode.length() == 0) {
                System.out.println("The service code cannot be blank.");
                return;
            }

            System.out.print("Priority (Normal/Express): ");
            String priority = reader.readLine().trim();
            boolean validPriority = priority.equalsIgnoreCase("Normal")
                    || priority.equalsIgnoreCase("Express");
            if (!validPriority) {
                System.out.println("The priority must be Normal or Express.");
                return;
            }

            Socket socket = new Socket(HOST, PORT);
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());

            output.writeObject(new BillRequest(studentId, serviceCode, priority));
            output.flush();

            BillResponse response = (BillResponse) input.readObject();
            display(response);

            socket.close();

        } catch (Exception e) {
            System.out.println("The client stopped: " + e.getMessage());
        }
    }

    // build the bill with a StringBuilder and print it
    private void display(BillResponse r) {
        System.out.println();
        if (!r.isFound()) {
            System.out.println(">> " + r.getMessage());
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("*********** CampusConnect Bill ***********\n");
        sb.append(" Student    : ").append(r.getStudentName()).append("\n");
        sb.append(" Age        : ").append(r.getStudentAge()).append("\n");
        sb.append(" Scholarship: ").append(r.getScholarship()).append("\n");
        sb.append(" Service    : ").append(r.getServiceDescription()).append("\n");
        sb.append("------------------------------------------\n");
        sb.append(String.format(" Base fee        : OMR %.2f%n", r.getBaseFee()));
        sb.append(String.format(" Scholarship off : OMR -%.2f%n", r.getScholarshipDiscount()));
        sb.append(String.format(" Age adjustment  : OMR %+.2f%n", r.getAgeAdjustment()));
        sb.append(String.format(" Priority charge : OMR +%.2f%n", r.getPriorityCharge()));
        sb.append("------------------------------------------\n");
        sb.append(String.format(" AMOUNT TO PAY   : OMR %.2f%n", r.getAmountToPay()));
        sb.append(" Delivery time   : ").append(r.getDeliveryTime()).append("\n");
        sb.append("******************************************");
        System.out.println(sb.toString());
    }

    public static void main(String[] args) {
        new BillingClient().start();
    }
}
