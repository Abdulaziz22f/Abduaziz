package campusbilling;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// Model A: every percent is measured against the original base fee, then summed.
public class BillingCalculator {

    public BillResponse computeBill(StudentRecord student, ServiceRecord service, String priority) {

        double base = service.getBaseFee();
        boolean express = priority.equalsIgnoreCase("Express");

        double discount = percentOf(base, scholarshipPercent(student.getScholarship()));
        double ageChange = percentOf(base, agePercent(student.getAge()));
        double priorityFee = express ? percentOf(base, 10) : 0.0;
        String window = express ? "15 to 20 minutes" : "30 to 45 minutes";

        double total = twoPlaces(base - discount + ageChange + priorityFee);

        return new BillResponse(
                student.getFullName(), student.getAge(), student.getScholarship(),
                service.getDescription(), twoPlaces(base), discount, ageChange,
                priorityFee, total, window);
    }

    // scholarship percent (None/unknown gives 0)
    private int scholarshipPercent(String type) {
        if (type == null) return 0;
        switch (type.toLowerCase()) {
            case "dean's list":               return 15;
            case "economically weak":          return 20;
            case "employee special support":   return 10;
            default:                           return 0;
        }
    }

    // age band: -5 for 18 or under, +5 for over 23, else 0
    private int agePercent(int age) {
        if (age <= 18) return -5;
        if (age > 23)  return 5;
        return 0;
    }

    private double percentOf(double amount, int percent) {
        return twoPlaces(amount * percent / 100.0);
    }

    private double twoPlaces(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
