package campusbilling;

import java.io.Serializable;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// what the server returns once the bill is worked out. The amounts are kept as
// double, and when a lookup misses, found is set false with a short reason.
public class BillResponse implements Serializable {

    private boolean found;
    private String message;

    private String studentName;
    private int studentAge;
    private String scholarship;
    private String serviceDescription;

    private double baseFee;
    private double scholarshipDiscount;
    private double ageAdjustment;
    private double priorityCharge;
    private double amountToPay;
    private String deliveryTime;

    // success
    public BillResponse(String studentName, int studentAge, String scholarship,
                        String serviceDescription, double baseFee, double scholarshipDiscount,
                        double ageAdjustment, double priorityCharge, double amountToPay,
                        String deliveryTime) {
        this.found = true;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.scholarship = scholarship;
        this.serviceDescription = serviceDescription;
        this.baseFee = baseFee;
        this.scholarshipDiscount = scholarshipDiscount;
        this.ageAdjustment = ageAdjustment;
        this.priorityCharge = priorityCharge;
        this.amountToPay = amountToPay;
        this.deliveryTime = deliveryTime;
    }

    // not found
    public BillResponse(String message) {
        this.found = false;
        this.message = message;
    }

    public boolean isFound()             { return found; }
    public String getMessage()           { return message; }
    public String getStudentName()       { return studentName; }
    public int getStudentAge()           { return studentAge; }
    public String getScholarship()       { return scholarship; }
    public String getServiceDescription(){ return serviceDescription; }
    public double getBaseFee()            { return baseFee; }
    public double getScholarshipDiscount(){ return scholarshipDiscount; }
    public double getAgeAdjustment()      { return ageAdjustment; }
    public double getPriorityCharge()     { return priorityCharge; }
    public double getAmountToPay()        { return amountToPay; }
    public String getDeliveryTime()       { return deliveryTime; }
}
