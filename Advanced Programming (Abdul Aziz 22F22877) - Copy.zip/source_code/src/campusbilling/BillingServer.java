package campusbilling;

import java.net.ServerSocket;
import java.net.Socket;

// Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
// opens a ServerSocket on 5050. Whenever someone connects I pass that socket to its own BillingWorker.
public class BillingServer {

    private static final int PORT = 5050;

    public static void main(String[] args) {

        System.out.println("+-------------------------------------------------+");
        System.out.printf ("| %-47s |%n", "CampusConnect Oman  -  Billing Server");
        System.out.printf ("| %-47s |%n", "Abdul Aziz Harith Salim Al Shibli (22F22877)");
        System.out.printf ("| %-47s |%n", "Module: COMP 20014.1  Advanced Programming");
        System.out.println("+-------------------------------------------------+");
        System.out.println("Billing server started.");
        System.out.println("Waiting for students on port " + PORT + " ...");

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("A client connected from " + socket.getInetAddress());
                new BillingWorker(socket).start();      // give this connection its own worker
            }
        } catch (Exception e) {
            System.out.println("The server could not run: " + e.getMessage());
        }
    }
}
