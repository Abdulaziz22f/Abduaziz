-- Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
-- Step 1: remove any old copy of the database, build a fresh one, then switch into it
DROP DATABASE IF EXISTS campusconnect;
CREATE DATABASE campusconnect CHARACTER SET utf8mb4;
USE campusconnect;

-- Step 2: make the two tables (the primary key is set as a separate constraint)
-- student details
CREATE TABLE student (
    id                INT          NOT NULL,
    name              VARCHAR(60)  NOT NULL,
    age               INT          NOT NULL,
    scholarship_type  VARCHAR(30),
    PRIMARY KEY (id)
);

-- service details and base fee (DECIMAL keeps the money exact)
CREATE TABLE service (
    service_code  VARCHAR(5)    NOT NULL,
    description   VARCHAR(40)   NOT NULL,
    base_fee      DECIMAL(5,2)  NOT NULL,
    PRIMARY KEY (service_code)
);

-- Student: Abdul Aziz Harith Salim Al Shibli (22F22877)
-- Step 3: add my six students and the five services so I can test every rule.
-- ages 17 and 18 (<=18 band), 20 and 22 (middle band), 26 and 29 (>23 band),
-- all scholarship types plus one student on None
INSERT INTO student (id, name, age, scholarship_type) VALUES
 (3301, 'Hilal Abdullah Al-Rashdi', 17, 'Dean''s List'),
 (3302, 'Amna Saif Al-Kindi',       20, 'Economically Weak'),
 (3303, 'Tariq Salim Al-Maamari',   26, 'Employee Special Support'),
 (3304, 'Latifa Hamed Al-Saadi',    22, 'None'),
 (3305, 'Omar Khalid Al-Farsi',     18, 'Economically Weak'),
 (3306, 'Shamsa Ali Al-Ghafri',     29, 'Dean''s List');

INSERT INTO service (service_code, description, base_fee) VALUES
 ('FD100', 'Food Delivery',        2.50),
 ('TR200', 'Transport Booking',    4.00),
 ('PR300', 'Printing Service',     1.50),
 ('EV400', 'Event Ticket Booking', 6.00),
 ('ST500', 'Study Room Booking',   3.50);
